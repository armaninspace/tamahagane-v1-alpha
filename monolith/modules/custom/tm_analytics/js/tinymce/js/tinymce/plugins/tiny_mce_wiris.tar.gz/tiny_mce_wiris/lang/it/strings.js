var strings = new Array();
strings['cancel'] = 'Annulla';
strings['accept'] = 'Accetta';
strings['manual'] = 'Manuale';
strings['latex'] = 'LaTeX';
strings['close'] = 'Close';
strings['minimise'] = 'Minimise';
strings['fullscreen'] = 'Full-screen';