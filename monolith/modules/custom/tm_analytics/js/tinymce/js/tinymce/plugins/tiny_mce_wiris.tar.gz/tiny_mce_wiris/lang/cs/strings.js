var strings = new Array();
strings['cancel'] = 'Storno';
strings['accept'] = 'OK';
strings['manual'] = 'Příručka';
strings['latex'] = 'LaTeX';
strings['close'] = 'Close';
strings['minimise'] = 'Minimise';
strings['fullscreen'] = 'Full-screen';