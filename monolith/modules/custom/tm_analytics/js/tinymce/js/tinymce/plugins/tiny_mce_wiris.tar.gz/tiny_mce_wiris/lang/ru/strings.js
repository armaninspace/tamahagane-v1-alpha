var strings = new Array();
strings['cancel'] = 'отмена';
strings['accept'] = 'OK';
strings['manual'] = 'вручную';
strings['latex'] = 'LaTeX';
strings['close'] = 'Close';
strings['minimise'] = 'Minimise';
strings['fullscreen'] = 'Full-screen';